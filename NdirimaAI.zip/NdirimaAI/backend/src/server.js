import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';

const app = express();
app.use(express.json({ limit: '64kb' }));

const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL;
const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey && model ? new OpenAI({ apiKey }) : null;

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', configured: Boolean(apiKey && model), model: model || null });
});

app.post('/chat', async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: 'OPENAI_API_KEY cyangwa OPENAI_MODEL ntabwo yashyizweho kuri backend.' });
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message) return res.status(400).json({ error: 'message irakenewe.' });
    if (message.length > 12000) return res.status(413).json({ error: 'message ni ndende cyane.' });

    const response = await client.responses.create({
      model,
      instructions: 'Uri Ndirima AI. Subiza cyane cyane mu Kinyarwanda, mu buryo busobanutse, bugufi kandi bufasha. Niba ikibazo gisaba ibisobanuro birambuye, bikore mu ngingo.',
      input: message
    });

    res.json({ reply: response.output_text || 'Nta gisubizo cyabonetse.' });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Seriveri yananiwe gutanga igisubizo.' });
  }
});

app.listen(port, () => console.log(`Ndirima AI backend listening on port ${port}`));
