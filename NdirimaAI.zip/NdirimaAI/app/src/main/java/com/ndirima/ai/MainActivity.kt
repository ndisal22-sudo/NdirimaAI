package com.ndirima.ai

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val messages = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val input = findViewById<EditText>(R.id.messageInput)
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            addMessage(ChatMessage("Wowe", text, true))
            input.setText("")
            sendToBackend(text)
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            messages.clear(); adapter.notifyDataSetChanged()
        }
    }

    private fun addMessage(message: ChatMessage) {
        messages.add(message); adapter.notifyItemInserted(messages.lastIndex)
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.lastIndex)
    }

    private fun sendToBackend(message: String) {
        findViewById<Button>(R.id.sendButton).isEnabled = false
        executor.execute {
            try {
                val base = BuildConfig.BACKEND_URL.trimEnd('/')
                require(base.startsWith("https://")) { "Backend URL igomba kuba HTTPS." }
                val connection = (URL("$base/chat").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                }
                val body = JSONObject().put("message", message).toString()
                connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw IllegalStateException("Server error $code: $response")
                val reply = JSONObject(response).optString("reply", "Nta gisubizo cyagarutse.")
                runOnUiThread { addMessage(ChatMessage("Ndirima AI", reply, false)) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Habaye ikibazo: ${e.message}", Toast.LENGTH_LONG).show() }
            } finally {
                runOnUiThread { findViewById<Button>(R.id.sendButton).isEnabled = true }
            }
        }
    }

    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
}

data class ChatMessage(val author: String, val text: String, val fromUser: Boolean)

class ChatAdapter(private val items: List<ChatMessage>) : RecyclerView.Adapter<ChatAdapter.Holder>() {
    class Holder(v: View) : RecyclerView.ViewHolder(v) { val text: TextView = v.findViewById(android.R.id.text1) }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1, parent, false)
        return Holder(view)
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val m = items[position]
        holder.text.text = "${m.author}: ${m.text}"
        holder.text.setPadding(12, 10, 12, 10)
    }
    override fun getItemCount() = items.size
}
