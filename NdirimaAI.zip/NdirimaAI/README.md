# Ndirima AI

Ndirima AI ni Android app y'ikiganiro cyubatswe na Kotlin, ihuza na Node.js/Express backend ikoresha OpenAI SDK. API key ibikwa kuri backend gusa; ntabwo ishyirwa muri APK.

## Ibisabwa
- Android Studio / Android SDK 35
- JDK 17
- Gradle 8.9
- Node.js 22+
- Backend ikorerwa kuri HTTPS iyo app iri hanze ya development

Android project ikoresha `minSdk 24`, `targetSdk 35`, package `com.ndirima.ai`.

## 1. Gutegura backend

```bash
cd backend
npm install
cp .env.example .env
```

Fungura `.env`, ushyiremo:

```env
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.6
PORT=3000
```

Tangira:

```bash
npm start
```

Reba health:

```bash
curl http://localhost:3000/health
```

Test chat:

```bash
curl -X POST http://localhost:3000/chat \
  -H 'Content-Type: application/json' \
  -d '{"message":"Muraho Ndirima AI"}'
```

## 2. Gushyiraho backend URL muri Android

Muri `app/build.gradle.kts`, hindura:

```kotlin
buildConfigField("String", "BACKEND_URL", "\"https://YOUR-BACKEND.example.com/\"")
```

**Koresha HTTPS.** Ntushyire `OPENAI_API_KEY` muri Gradle, Kotlin, resources cyangwa APK.

## 3. Kubaka APK

Ku mashini ifite Android SDK 35 na JDK 17
- Gradle 8.9:

```bash
gradle clean assembleDebug
```

APK izaba hano:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 4. GitHub Actions

Workflow iri muri `.github/workflows/android.yml` kandi yubaka `assembleDebug`, ikora checks za Gradle, hanyuma igashyira debug APK nka artifact.

## 5. Imiterere ya repository

```text
NdirimaAI/
├── app/
├── backend/
├── .github/workflows/android.yml
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```
